const express = require('express');
const path = require('path');
const bcrypt = require('bcrypt');
const session = require('express-session');
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const collection = require('./config');

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

app.use(session({
    secret: 'qwerty',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 1000 * 60 * 60 }
}));

// Middleware для проверки авторизации и 2FA
function checkAuth(req, res, next) {
    if (req.session.user && req.session.is2FAVerified) {
        return next();
    }
    res.redirect('/');
}

app.get('/', (req, res) => {
    res.render('login');
});

app.get('/signup', (req, res) => {
    res.render('signup');
});

app.get('/home', checkAuth, (req, res) => {
    res.render('home', { username: req.session.user });
});

app.post('/signup', async (req, res) => {
    const { username, password } = req.body;
    const existingUser = await collection.findOne({ name: username });

    if (existingUser) {
        return res.send('User already exists.');
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new collection({ name: username, password: hashedPassword });
    await newUser.save();

    res.render('success', { username });
});

app.post('/login', async (req, res) => {
    try {
        const user = await collection.findOne({ name: req.body.username });
        if (!user) return res.send('Username not found');
        if (user.isLocked) return res.send('Your account is locked.');

        const isPasswordMatch = await bcrypt.compare(req.body.password, user.password);

        if (isPasswordMatch) {
            user.failedAttempts = 0;
            user.isLocked = false;
            await user.save();

            req.session.user = user.name;
            req.session.userId = user._id; 
            req.session.is2FAVerified = false; // Сбрасываем перед проверкой 2FA

            if (user.is2FAEnabled) {
                return res.redirect('/verify-2fa'); // Редиректим на страницу 2FA
            }

            req.session.is2FAVerified = true;
            return res.redirect('/home');
        } else {
            user.failedAttempts++;
            if (user.failedAttempts >= 5) user.isLocked = true;
            await user.save();
            return res.send('Wrong password.');
        }
    } catch (err) {
        console.error(err);
        res.send('Error during login');
    }
});


app.get('/setup-2fa', checkAuth, async (req, res) => {
    try {
        const user = await collection.findOne({ name: req.session.user });
        if (!user) return res.send('User not found.');
        if (user.is2FAEnabled && user.twoFASecret) return res.send('2FA is already enabled.');

        const secret = speakeasy.generateSecret({ length: 20 });
        console.log("Generated secret:", secret.base32);

        const updatedUser = await collection.findOneAndUpdate(
            { _id: user._id },
            { $set: { twoFASecret: secret.base32, is2FAEnabled: true } },
            { new: true }
        );

        console.log("Updated user after setup:", updatedUser); // Проверяем обновление

        if (!updatedUser.twoFASecret) {
            return res.send("Error saving 2FA secret to database");
        }

        const otpauthUrl = `otpauth://totp/MyApp:${user.name}?secret=${secret.base32}&issuer=MyApp`;

        QRCode.toDataURL(otpauthUrl, (err, url) => {
            if (err) {
                console.error('Error generating QR code:', err);
                return res.send('Error generating QR code');
            }
            res.render('setup-2fa', { qrCode: url });
        });

    } catch (error) {
        console.error('Error setting up 2FA:', error);
        res.send('Error setting up 2FA');
    }
});





app.post('/verify-2fa', async (req, res) => {
    const user = await collection.findOne({ _id: req.session.userId });
    if (!user || !user.twoFASecret) return res.send('2FA is not set up.');

    const isValid = speakeasy.totp.verify({
        secret: user.twoFASecret,
        encoding: 'base32',
        token: req.body.otp,
        window: 1
    });

    if (isValid) {
        req.session.is2FAVerified = true;
        return res.redirect('/home');
    } else {
        return res.send('Invalid OTP. Try again.');
    }
});



app.listen(port, () => {
    console.log(`Server running at: http://localhost:${port}`);
});
