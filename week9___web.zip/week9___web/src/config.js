const mongoose = require('mongoose');

async function connectDB() {
    try {
        await mongoose.connect('mongodb://127.0.0.1:27017/myApp', {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            serverSelectionTimeoutMS: 30000,
        });

        console.log('✅ Connected to MongoDB');
        console.log('🗄️ Using database:', mongoose.connection.db.databaseName);
    } catch (err) {
        console.error('❌ Connection Error:', err);
    }
}

connectDB();

const LoginSchema = new mongoose.Schema({
    name: { type: String, required: true },
    password: { type: String, required: true },
    failedAttempts: { type: Number, default: 0 },
    isLocked: { type: Boolean, default: false },
    twoFASecret: { type: String, default: null },
    is2FAEnabled: { type: Boolean, default: false }
});

const collection = mongoose.model('users', LoginSchema);

module.exports = collection;
