const mongoose = require('mongoose');

const readerSchema = new mongoose.Schema({
  name: String,
  email: String
});

module.exports = mongoose.model('Reader', readerSchema);
